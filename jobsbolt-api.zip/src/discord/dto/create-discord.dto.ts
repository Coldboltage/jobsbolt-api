export class CreateDiscordDto {}
